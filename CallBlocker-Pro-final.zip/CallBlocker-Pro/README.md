# CallBlocker Pro

Projeto Android nativo (Kotlin + Jetpack Compose) para filtragem de chamadas recebidas por lista de permissões.

## Regras
- Contatos da agenda são permitidos quando o usuário concede `READ_CONTACTS`.
- Números adicionados manualmente são permitidos.
- Números fora da lista, inclusive número oculto/privado, são rejeitados pelo `CallScreeningService`.
- A rejeição de chamadas não desativa dados móveis, Wi-Fi ou WhatsApp.
- O app não solicita permissão de internet e não mantém serviço permanente.

## Requisitos
- Android 8.0 (API 26) ou superior.
- Android SDK 35 e JDK 17 para compilar.
- O usuário precisa definir o CallBlocker Pro como aplicativo de identificação/filtro de chamadas nas configurações de função do Android.

## Gerar APK
O GitHub Actions compila automaticamente em cada push na branch `main`. Também é possível iniciar manualmente em **Actions → Build CallBlocker Pro APK → Run workflow**. O arquivo `app-debug.apk` fica nos artefatos da execução.

## Observações importantes
- A primeira versão é um bloqueador por lista de permissões; não consulta bases externas de spam.
- O Android/Samsung pode manter registros próprios de chamadas rejeitadas, conforme versão e configuração do aparelho.
- O comportamento precisa ser validado em aparelho real antes de uso como bloqueador principal. O serviço responde imediatamente ao Android e grava um histórico local simples.
