package com.xflux.callblocker

import android.telecom.Call
import android.telecom.CallScreeningService

class CallBlockerService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, CallResponse.Builder().build())
            return
        }
        val raw = details.handle?.schemeSpecificPart.orEmpty()
        val allowed = AllowList.isAllowed(this, raw)
        val response = CallResponse.Builder()
            .setDisallowCall(!allowed)
            .setRejectCall(!allowed)
            .setSkipNotification(!allowed)
            .build()
        respondToCall(details, response)
        if (!allowed) BlockHistory.add(this, raw)
    }
}
