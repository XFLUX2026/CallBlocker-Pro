package com.xflux.callblocker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object BlockHistory {
    private const val PREF = "history"
    fun add(context: Context, number: String) {
        val p = context.getSharedPreferences(PREF, 0)
        val old = try { JSONArray(p.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val next = JSONArray().put(JSONObject().put("number", number.ifBlank { "Número oculto" }).put("time", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 99)) next.put(old.getJSONObject(i))
        p.edit().putString("items", next.toString()).apply()
    }
    fun count(context: Context): Int = try { JSONArray(context.getSharedPreferences(PREF, 0).getString("items", "[]")).length() } catch (_: Exception) { 0 }
}
